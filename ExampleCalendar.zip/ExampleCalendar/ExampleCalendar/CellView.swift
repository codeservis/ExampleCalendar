//
//  CellView.swift
//  ExampleCalendar
//

import JTAppleCalendar

class CellView: JTAppleCell {
    @IBOutlet var selectedView: UIView!
    @IBOutlet var dayLabel: UILabel!
}
