//
//  ViewController.swift

import UIKit
import Foundation
import JTAppleCalendar
import CoreData

class ViewController: UIViewController, UIGestureRecognizerDelegate  {
    
    override var prefersStatusBarHidden : Bool {
        return true
    }
    
    @IBOutlet weak var calendarView: JTAppleCalendarView!
    @IBOutlet weak var ayBilgi: UILabel!
    
    let months = [
        "1",
        "2",
        "3",
        "4",
        "5",
        "6",
        "7",
        "8",
        "9",
        "10",
        "11",
        "12" ]
    let kStartDate = "2016-01-01"
    let kEndDate = "2049-12-31"
    var numberOfRows = 6
    let formatter = DateFormatter()
    var myCalendar = Calendar(identifier: .gregorian)
    var generateInDates: InDateCellGeneration = .forFirstMonthOnly
    var generateOutDates: OutDateCellGeneration = .off
    var hasStrictBoundaries = true
    let firstDayOfWeek: DaysOfWeek = .monday
    var monthSize: MonthSize? = nil
    
    
    
    var myDataSource = [mydata]()
    
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        
        formatter.dateFormat = "yyyy-MM-dd"
        formatter.timeZone = TimeZone(secondsFromGMT: 0)
        formatter.locale = Locale(identifier: "en_US")
        
        
        self.calendarView.selectDates([NSDate() as Date])
        self.calendarView.scrollToDate(NSDate() as Date, animateScroll: true)
        self.calendarView.visibleDates({ (visibleDates: DateSegmentInfo) in
            self.setupViewsOfCalendar(from: visibleDates)
        })
        
        
        myDataSource.removeAll()
        myDataSource.append(mydata(mydate: "2018-03-12", id : 12))
        myDataSource.append(mydata(mydate: "2018-03-09", id : 17))
        myDataSource.append(mydata(mydate: "2018-03-02", id : 23))
        myDataSource.append(mydata(mydate: "2018-04-05", id : 49))
        myDataSource.append(mydata(mydate: "2018-04-18", id : 58))
        myDataSource.append(mydata(mydate: "2018-04-22", id : 88))
        
        
    }
    
    override func viewWillAppear(_ animated: Bool) {
        super.viewWillAppear(animated)
    }
    
    override func viewDidAppear(_ animated: Bool) {
        super.viewDidAppear(animated)
    }
    
    @IBAction func next(_ sender: Any) {
        self.calendarView.scrollToSegment(.next) {
            self.calendarView.visibleDates({ (visibleDates: DateSegmentInfo) in
                self.setupViewsOfCalendar(from: visibleDates)
            })
        }
    }
    
    @IBAction func prev(_ sender: Any) {
        self.calendarView.scrollToSegment(.previous) {
            self.calendarView.visibleDates({ (visibleDates: DateSegmentInfo) in
                self.setupViewsOfCalendar(from: visibleDates)
            })
        }
    }
    
    @IBAction func today(_ sender: Any) {
        self.calendarView.selectDates([NSDate() as Date])
        self.calendarView.scrollToDate(NSDate() as Date, animateScroll: true)
        self.calendarView.visibleDates({ (visibleDates: DateSegmentInfo) in
            self.setupViewsOfCalendar(from: visibleDates)
        })
    }
   
    
    func setupViewsOfCalendar(from visibleDates: DateSegmentInfo) {
        guard let startDate = visibleDates.monthDates.first?.date else {
            return
        }
        let month = myCalendar.dateComponents([.month], from: startDate).month!
        let monthName = months[(month-1) % 12]
        let year = myCalendar.component(.year, from: startDate)
        ayBilgi.text = monthName + " " + String(year)
    }
    
    func handleCellTextColor(view: JTAppleCell?, cellState: CellState) {
        guard let cell = view as? CellView  else {
            return
        }
        
        
        cell.dayLabel.text = cellState.text
        
        
        
        
        if cellState.isSelected {
            cell.dayLabel.textColor = UIColor.white
        } else {
            
            
            if cellState.dateBelongsTo == .thisMonth {
                if myCalendar.isDateInToday(cellState.date) {
                    cell.dayLabel.textColor = UIColor.red
                } else {
                    cell.dayLabel.textColor = UIColor.black
                }
            } else {
                cell.dayLabel.textColor = UIColor.init(red: 0.875, green: 0.875, blue: 0.875, alpha: 1)
            }
        }
    }
    
    
    func tap(_ sender:UIGestureRecognizer)
    {
        let label = (sender.view as! UILabel)
        print("\(label.text!) id = \(label.tag)")
    }
    func longPress(_ sender:UIGestureRecognizer)
    {
        let label = (sender.view as! UILabel)
        print("\(label.text!) id = \(label.tag)")
    }
    
    
    func handleCellSelection(view: JTAppleCell?, cellState: CellState) {
        guard let cell = view as? CellView else {return }
        if cellState.isSelected {
            
            cell.dayLabel.textColor = UIColor.white
            cell.selectedView.layer.cornerRadius =  cell.selectedView.frame.size.width / 2
            cell.selectedView.isHidden = false
            if myCalendar.isDateInToday(cellState.date) {
                cell.selectedView.backgroundColor = UIColor.red
            } else {
                cell.selectedView.backgroundColor = UIColor.black
            }
        } else {
            cell.selectedView.isHidden = true
        }
        
        cell.selectedView.transform = CGAffineTransform(scaleX: 0.5, y: 0.5)
        UIView.animate(
            withDuration: 0.5,
            delay: 0, usingSpringWithDamping: 0.3,
            initialSpringVelocity: 0.1,
            options: UIViewAnimationOptions.beginFromCurrentState,
            animations: {
                cell.selectedView.transform = CGAffineTransform(scaleX: 1, y: 1)
        },
            completion: nil
        )
    }
    
    func handleCellConfiguration(cell: JTAppleCell?, cellState: CellState) {
        handleCellSelection(view: cell, cellState: cellState)
        handleCellTextColor(view: cell, cellState: cellState)
    }
}

extension ViewController: JTAppleCalendarViewDelegate, JTAppleCalendarViewDataSource {
    
    func configureCalendar(_ calendar: JTAppleCalendarView) -> ConfigurationParameters {
        
        formatter.dateFormat = "yyyy-MM-dd"
        formatter.timeZone = TimeZone(secondsFromGMT: 0)
        formatter.locale = Locale(identifier: "en_US")
        
        let startDate = formatter.date(from: kStartDate)!
        let endDate = formatter.date(from: kEndDate)!
        
        let parameters = ConfigurationParameters(startDate: startDate,
                                                 endDate: endDate,
                                                 numberOfRows: numberOfRows,
                                                 calendar: myCalendar,
                                                 generateInDates: generateInDates,
                                                 generateOutDates: generateOutDates,
                                                 firstDayOfWeek: firstDayOfWeek,
                                                 hasStrictBoundaries: hasStrictBoundaries)
        return parameters
    }
    
    func calendar(_ calendar: JTAppleCalendarView, cellForItemAt date: Date, cellState: CellState, indexPath: IndexPath) -> JTAppleCell {
        let cell = calendar.dequeueReusableCell(withReuseIdentifier: "CellView", for: indexPath) as! CellView
        
        // HERE newdate must be show like "yyyy-MM-dd"
        
        let bigdate = String(describing: myCalendar.date(byAdding: .day, value: 1, to: cellState.date))
        let index = bigdate.index(bigdate.startIndex, offsetBy: 9)
        let index2 = bigdate.index(index, offsetBy: 10)
        var newdate = bigdate.substring(from: index)
        newdate = newdate.substring(to: index2)
        print(newdate)
        //
        
        
        let myObjectForThisCell = myDataSource[newdate]
        
        
        if(myObjectForThisCell.mydate == newdate && myObjectForThisCell.id == 12)
            
        {
            
            cell.dayLabel.text = cellState.text
            cell.selectedView.backgroundColor = UIColor.red
            
            
        }
        else if(myObjectForThisCell.mydate == newdate && myObjectForThisCell.id == 58)
        {
            cell.dayLabel.text = cellState.text
            cell.selectedView.backgroundColor = UIColor.green
            
        }else{
            
            
            cell.contentView.backgroundColor = UIColor.white
            
            
        }
       
        
        
        
        handleCellConfiguration(cell: cell, cellState: cellState)
        return cell
    }
    
    func calendar(_ calendar: JTAppleCalendarView, didDeselectDate date: Date, cell: JTAppleCell?, cellState: CellState) {
        
        
        handleCellConfiguration(cell: cell, cellState: cellState)
    }
    
    func calendar(_ calendar: JTAppleCalendarView, didSelectDate date: Date, cell: JTAppleCell?, cellState: CellState) {
        
        
        let formatter = DateFormatter()
        formatter.dateFormat = "yyyy-MM-dd"
        print("date = \(formatter.string(from: date))")
        
        handleCellConfiguration(cell: cell, cellState: cellState)
    }
    
    
    
    
    func calendar(_ calendar: JTAppleCalendarView, didScrollToDateSegmentWith visibleDates: DateSegmentInfo) {
        self.setupViewsOfCalendar(from: visibleDates)
    }
    
    func scrollDidEndDecelerating(for calendar: JTAppleCalendarView) {
        let visibleDates = calendarView.visibleDates()
        self.setupViewsOfCalendar(from: visibleDates)
    }
    
    func calendarSizeForMonths(_ calendar: JTAppleCalendarView?) -> MonthSize? {
        return monthSize
    }
}


