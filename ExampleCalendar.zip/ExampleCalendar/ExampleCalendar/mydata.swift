//
//  mydata.swift
//  ExampleCalendar
//
//  Created by Talha on 1.05.2017.
//  Copyright © 2017 ExampleCalendar. All rights reserved.
//

import Foundation

class mydata : NSObject {
    let mydate: String
    var id: Int
    
    init(mydate: String, id: Int) {
        self.mydate = mydate
        self.id = id
    }
    
    
}
