//
//  mydata.swift
//  ExampleCalendar
//

import Foundation

class mydata : NSObject {
    let mydate: String
    var id: Int
    
    init(mydate: String, id: Int) {
        self.mydate = mydate
        self.id = id
    }
    
    
}
